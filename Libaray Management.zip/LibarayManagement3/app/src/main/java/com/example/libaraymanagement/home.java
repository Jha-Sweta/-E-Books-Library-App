package com.example.libaraymanagement;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

public class home extends AppCompatActivity {
    ImageView img1,img2,img3,img4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        img1 = (ImageView) findViewById(R.id.m1);
        img2 = (ImageView) findViewById(R.id.m2);
        img3 = (ImageView) findViewById(R.id.m3);
        img4 = (ImageView) findViewById(R.id.m4);

        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(home.this,magazine.class);
                startActivity(intent);
            }
        });
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(home.this,stroy.class);
                startActivity(intent);
            }
        });
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(home.this,study.class);
                startActivity(intent);
            }
        });
        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(home.this,novels.class);
                startActivity(intent);
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();


        if(id==R.id.menu_contact){
            Intent intent = new Intent(this, contact.class);
            startActivity(intent);
        }

        if(id==R.id.menu_about){
            Intent intent = new Intent(this, about.class);
            startActivity(intent);
        }

        if(id==R.id.menu_libray){
            Intent intent = new Intent(this, libray.class);
            startActivity(intent);
        }

        if(id==R.id.menu_share){
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(intent.EXTRA_SUBJECT,"Checkout this cool application");
            intent.putExtra(intent.EXTRA_TEXT,"your application link is here http://schemas.android.com/apk/res/android");
            startActivity(intent.createChooser(intent,"share via"));
        }
        return super.onOptionsItemSelected(item);
    }
}