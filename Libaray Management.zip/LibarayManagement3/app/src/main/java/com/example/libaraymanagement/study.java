package com.example.libaraymanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class study extends AppCompatActivity {
    TextView t1,t2,t3,t4,t5,t6,t7,t8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_libray);
        t1 = (TextView) findViewById(R.id.pdf1);
        t2 = (TextView) findViewById(R.id.pdf2);
        t3 = (TextView) findViewById(R.id.pdf3);
        t4 = (TextView) findViewById(R.id.pdf4);
        t5 = (TextView) findViewById(R.id.pdf5);
        t6 = (TextView) findViewById(R.id.pdf6);
        t7 = (TextView) findViewById(R.id.pdf7);
        t8 = (TextView) findViewById(R.id.pdf8);

        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://drive.google.com/file/d/1MS85gPxgGnOGRwYu5q5Uj6zDQba9jo-A/view?usp=drivesdk"));
                startActivity(intent);
            }
        });
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://drive.google.com/file/d/1MXl9geKFtsNKuuVvo3GDHRyN1EOuwzwW/view?usp=drivesdk"));
                startActivity(intent);
            }
        });
        t3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://drive.google.com/file/d/1MMaVZ1kwtqrCpWCyCiJpHqRIbRbDYxkd/view?usp=drivesdk"));
                startActivity(intent);
            }
        });
        t4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://drive.google.com/file/d/1M5caueRJD5tLtjOoxLJu6VLVM9fvNyHU/view?usp=drivesdk"));
                startActivity(intent);
            }
        });

        t5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://drive.google.com/file/d/1M5caueRJD5tLtjOoxLJu6VLVM9fvNyHU/view?usp=drivesdk"));
                startActivity(intent);
            }
        });
        t6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://drive.google.com/file/d/1M5caueRJD5tLtjOoxLJu6VLVM9fvNyHU/view?usp=drivesdk"));
                startActivity(intent);
            }
        });

        t7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://drive.google.com/file/d/1M5caueRJD5tLtjOoxLJu6VLVM9fvNyHU/view?usp=drivesdk"));
                startActivity(intent);
            }
        });
        t8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://drive.google.com/file/d/1MV-F0uGGkHu3EKY_xbJC7-yzgl0j1vLH/view?usp=drivesdk"));
                startActivity(intent);
            }
        });




    }

}